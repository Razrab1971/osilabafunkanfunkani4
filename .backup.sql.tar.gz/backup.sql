--
-- PostgreSQL database dump
--

\restrict xehWWQUYtZQ7jepvwzqpnUGxJ8utdKJrEdUmyd7YNRPJdnUwoWeaSRNgwsV3Eda

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: prevent_column_update(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.prevent_column_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF OLD.first_connect IS DISTINCT FROM NEW.first_connect THEN
		RAISE EXCEPTION 'Изменять время первого подключения запрещено';
	END IF;
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.prevent_column_update() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: type_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.type_user (
    text text NOT NULL
);


ALTER TABLE public.type_user OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id text NOT NULL,
    name character(21),
    type_user text,
    first_connect date NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: type_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.type_user (text) FROM stdin;
Разработчик
Пользователь
Забанен
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, type_user, first_connect) FROM stdin;
5705681781 	\N	Пользователь	2026-02-14
0976649556 	Хетар                	Пользователь	2026-02-14
0245498286 	Павел                	Пользователь	2026-02-14
\.


--
-- Name: type_user type_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.type_user
    ADD CONSTRAINT type_user_pkey PRIMARY KEY (text);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users present_users_first_connect; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER present_users_first_connect BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.prevent_column_update();


--
-- Name: users users_type_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_type_user_fkey FOREIGN KEY (type_user) REFERENCES public.type_user(text);


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO bot_tg;


--
-- PostgreSQL database dump complete
--

\unrestrict xehWWQUYtZQ7jepvwzqpnUGxJ8utdKJrEdUmyd7YNRPJdnUwoWeaSRNgwsV3Eda

